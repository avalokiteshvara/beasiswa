
-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `tipe` enum('small-text','big-text','link','option') DEFAULT 'small-text',
  `value` text DEFAULT NULL,
  `show` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Truncate table before insert `settings`
--

TRUNCATE TABLE `settings`;
--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `title`, `tipe`, `value`, `show`) VALUES
(1, 'frontpage_popup', 'big-text', '<p><img alt=\"\" src=\"https://i.ibb.co/JF32MJ2/Alur-Pendaftaran-Beasiswa.png\" style=\"height:1024px; width:768px\" /></p>\n', 'YA,TIDAK;YA'),
(2, 'frontpage_marquee', 'small-text', 'Silahkan Pilih Jalur Pendafaran Beasiswa Sesuai Jenjang yang Saudara Tempuh, Pastikan Saudara Sudah Membaca Persyaratan & Ketentuan Penerima. Jenjang S1 dan S3 Ada Perbedaan di Form Pendaftaran. Jenjang S3 Pada Pengisian NIDN Sistem Otomatis Sinkron ke Data PDDIKTI Untuk Pengecekan Data Dosen (NIDN Aktif).', 'YA,TIDAK;YA'),
(3, 'penambahan_tahap_berkas', 'small-text', '0', 'YA,TIDAK;TIDAK'),
(4, 'tahun_aktif', 'small-text', '2023', 'YA;YA'),
(5, 'image_slider', 'link', '/admin/image-slider', NULL),
(7, 'menu_lulus', 'option', 'TAHAP-1,TAHAP-2;TAHAP-1', 'YA,TIDAK;TIDAK');
