
-- --------------------------------------------------------

--
-- Table structure for table `kategori_qry_validation`
--

CREATE TABLE `kategori_qry_validation` (
  `id` int(11) NOT NULL,
  `kategori_id` int(11) NOT NULL,
  `qry` varchar(300) NOT NULL,
  `success_msg` varchar(50) NOT NULL,
  `error_msg` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Truncate table before insert `kategori_qry_validation`
--

TRUNCATE TABLE `kategori_qry_validation`;
--
-- Dumping data for table `kategori_qry_validation`
--

INSERT INTO `kategori_qry_validation` (`id`, `kategori_id`, `qry`, `success_msg`, `error_msg`) VALUES
(1, 1, 'SELECT IF(:kelas > 10, \'Y\',IF( :semester > 1 ,\'Y\',\'N\')) AS result', '', 'Persyaratan tidak terpenuhi !');
