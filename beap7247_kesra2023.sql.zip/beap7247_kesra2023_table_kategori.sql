
-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `short_name` varchar(100) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `sort_num` varchar(100) DEFAULT NULL,
  `level_penerima` enum('mahasiswa','pelajar','dosen') NOT NULL DEFAULT 'mahasiswa',
  `status_pendaftaran` enum('buka','tutup') NOT NULL DEFAULT 'buka',
  `upload_berkas` enum('buka','tutup') NOT NULL DEFAULT 'buka',
  `prefix_registrasi` char(6) DEFAULT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `persyaratan` text DEFAULT NULL,
  `set_jenis_dokumen` varchar(100) DEFAULT NULL,
  `tgl_buka` date DEFAULT NULL,
  `tgl_tutup` date DEFAULT NULL,
  `jml_penerima` smallint(6) DEFAULT NULL,
  `kelas` varchar(50) DEFAULT NULL,
  `akreditasi` varchar(50) DEFAULT NULL,
  `semester` varchar(50) DEFAULT NULL,
  `ip_minimal` varchar(9) DEFAULT NULL,
  `strict_ip_minimal` enum('Y','N') DEFAULT NULL,
  `template_lulus` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='\r\n\r\n';

--
-- Truncate table before insert `kategori`
--

TRUNCATE TABLE `kategori`;
--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `nama`, `short_name`, `logo`, `sort_num`, `level_penerima`, `status_pendaftaran`, `upload_berkas`, `prefix_registrasi`, `slug`, `persyaratan`, `set_jenis_dokumen`, `tgl_buka`, `tgl_tutup`, `jml_penerima`, `kelas`, `akreditasi`, `semester`, `ip_minimal`, `strict_ip_minimal`, `template_lulus`) VALUES
(3, 'Beasiswa Mahasiswa Strata Satu (S1) - Kurang Mampu', 'S1 - Kurang Mampu', '7d1c9-screenshot-2022-11-06-200508.jpg', '1', 'mahasiswa', 'buka', 'buka', 'S1-01', 'beasiswa-mahasiswa-strata-satu-s1-kurang-mampu', '<p>a. Terdaftar sebagai penduduk di Provinsi Jambi dibuktikan dengan Kartu Tanda Penduduk (KTP) dan Kartu Keluarga (KK);</p>\r\n\r\n<p>b. Terdaftar dalam daftar DKTS atau melampirkan surat keterangan kurang mampu dari RT dan Lurah&nbsp; setempat;</p>\r\n\r\n<p>c. Index Prestasi Kumulatif (IPK) minimal 2,75 (dua koma tujuh lima) untuk mahasiswa eksakta dan minimal 3.00 (tiga koma nol nol) untuk mahasiswa sosial/non eksakta</p>\r\n\r\n<p>d.&nbsp;melampirkan fotokopi Kartu Tanda Mahasiswa (KTM);</p>\r\n\r\n<p>e.&nbsp;melampirkan surat keterangan aktif kuliah dari program studi/fakultas/perguruan tinggi;</p>\r\n\r\n<p>f.&nbsp;surat pernyataan tidak sedang menerima bantuan beasiswa dari pihak lain yang diketahui oleh program studi/fakultas/perguruan tinggi;</p>\r\n\r\n<p>g.&nbsp;surat pernyataan bertanggung jawab dalam menggunakan dana bantuan beasiswa dan siap mengembalikan dana bantuan beasiswa apabila melanggar ketentuan yang telah ditentukan;</p>\r\n\r\n<p>h.&nbsp;melampirkan sertifikat akreditasi program studi; dan</p>\r\n\r\n<p>i.&nbsp;melampirkan rencana penggunaan anggaran bantuan.</p>\r\n', '7,4,3,1,15,6,22,25,16,11,5', '2023-07-01', '2023-07-22', 210, NULL, 'A,B,C', '1,2,3,4,5,6,7', '2.75:3.00', 'Y', 'de6c9-f1df5-tanda_bukti_merah.docx'),
(5, 'Beasiswa Mahasiswa Strata Tiga (S3) - Tenaga pengajar / Dosen Dalam Negeri', 'S3 - Dosen Dalam Negeri', '0022a-screenshot-2022-11-06-200615.jpg', '3', 'dosen', 'buka', 'buka', 'S3-01', 'beasiswa-mahasiswa-strata-tiga-s3-tenaga-pengajar-dosen-dalam-negeri', '<p>a. terdaftar sebagai penduduk di Provinsi Jambi dibuktikan dengan menunjukkan Kartu Tanda Penduduk (KTP)&nbsp;dan&nbsp;Kartu Keluarga (KK);</p>\r\n\r\n<p>b. Sudah memiliki Nomor Induk Dosen Nasional (NIDN) atau tenaga pengajar tetap pada perguruan tinggi dalam Provinsi jambi</p>\r\n\r\n<p>c. Indeks Prestasi Kumulatif (IPK) minimal 3,50 (tiga koma lima nol)</p>\r\n\r\n<p>d. melampirkan fotokopi Kartu Tanda Mahasiswa (KTM);</p>\r\n\r\n<p>e.&nbsp;melampirkan surat keterangan aktif kuliah dari program studi/fakultas/perguruan tinggi;</p>\r\n\r\n<p>f.&nbsp;melampirkan fotokopi hasil studi semester Kartu Hasi Studi (KHS) yang telah diperoleh;</p>\r\n\r\n<p>g.&nbsp;melampirkan sertifikat akreditasi program studi;</p>\r\n\r\n<p>h.&nbsp;melampirkan fotokopi SK Pengangkatan Dosen;</p>\r\n\r\n<p>i.&nbsp;melampirkan rencana penggunaan bantuan;&nbsp;</p>\r\n\r\n<p>j.&nbsp;surat pernyataan tidak sedang menerima bantuan beasiswa dari pihak lain yang diketahui oleh program studi/fakultas/perguruan tinggi;</p>\r\n\r\n<p>k.&nbsp;surat pernyataan bertanggung jawab dalam menggunakan dana bantuan beasiswa dan siap mengembalikan dana bantuan beasiswa apabila melanggar ketentuan yang telah ditetapkan; dan</p>\r\n\r\n<p>l.&nbsp;melampirkan rencana penelitian atau proposal penelitian berupa tugas akhir.</p>\r\n', '7,12,4,3,1,15,24,6,25,16,11,5', '2023-07-01', '2023-07-22', 70, NULL, 'A,B,C', '1,2,3,4,5,6', '3.50:3.50', 'Y', '9cb4e-e0f18-tanda_bukti_hijau.docx'),
(7, 'Beasiswa Mahasiswa Strata Satu (S1) - Berprestasi', 'S1 - Prestasi', '832ce-screenshot-2022-11-06-200551.jpg', '2', 'mahasiswa', 'buka', 'buka', 'S1-02', 'beasiswa-mahasiswa-strata-satu-s1-berprestasi', '<p>a. Terdaftar sebagai penduduk di Provinsi Jambi dibuktikan dengan menunjukkan Kartu Tanda Penduduk (KTP) dan Kartu Keluarga (KK);</p>\r\n\r\n<p>b. Index Prestasi Kumulatif (IPK) minimal 2,75 (dua koma tujuh lima) untuk mahasiswa eksakta dan minimal 3.00 (tiga koma nol nol) untuk mahasiswa sosial/non eksakta</p>\r\n\r\n<p>c.&nbsp;berprestasi akademik atau non akademik Tingkat Nasional atau Internasional dibuktikan dengan melampirkan sertifikat/piagam;</p>\r\n\r\n<p>d.&nbsp;melampirkan fotokopi Kartu Tanda Mahasiswa (KTM);</p>\r\n\r\n<p>e.&nbsp;melampirkan surat keterangan aktif kuliah dari program studi/fakultas/perguruan tinggi;</p>\r\n\r\n<p>f.&nbsp;melampirkan fotokopi hasil studi semester Kartu Hasil Studi (KHS) yang telah diperoleh;</p>\r\n\r\n<p>g.&nbsp;melampirkan sertifikat akreditas program studi;&nbsp;</p>\r\n\r\n<p>h.&nbsp;surat pernyataan tidak sedang menerima bantuan beasiswa dari pihak lain yang diketahui oleh program studi/fakultas/perguruan tinggi;</p>\r\n\r\n<p>i.&nbsp;surat pernyataan bertanggung jawab dalam menggunakan dana bantuan beasiswa dan siap mengembalikan dana bantuan beasiswa apabila melanggar ketentuan yang telah ditentukan; dan</p>\r\n\r\n<p>j.&nbsp;melampirkan rencana penggunaan anggaran bantuan beasiswa.</p>\r\n', '7,4,3,1,15,8,6,25,16,11,5', '2023-07-01', '2023-07-22', 90, NULL, 'A,B,C', '1,2,3,4,5,6,7', '2.75:3.00', 'Y', '25489-f1df5-tanda_bukti_navi.docx'),
(8, 'Beasiswa Mahasiswa Strata Tiga (S3) - Tenaga pengajar / Dosen Luar Negeri', 'S3 - Dosen Luar Negeri', 'de44f-screenshot-2022-11-06-200316.jpg', '4', 'dosen', 'buka', 'buka', 'S3-02', 'beasiswa-mahasiswa-strata-tiga-s3-tenaga-pengajar-dosen-luar-negeri', '<p>a. terdaftar sebagai penduduk di Provinsi Jambi dibuktikan dengan menunjukkan Kartu Tanda Penduduk (KTP)&nbsp;dan&nbsp;Kartu Keluarga (KK);</p>\r\n\r\n<p>b. Sudah memiliki Nomor Induk Dosen Nasional (NIDN) atau tenaga pengajar tetap pada perguruan tinggi dalam Provinsi jambi</p>\r\n\r\n<p>c. Indeks Prestasi Kumulatif (IPK) minimal 3,50 (tiga koma lima nol)</p>\r\n\r\n<p>d. melampirkan fotokopi Kartu Tanda Mahasiswa (KTM);</p>\r\n\r\n<p>e.&nbsp;melampirkan surat keterangan aktif kuliah dari program studi/fakultas/perguruan tinggi;</p>\r\n\r\n<p>f.&nbsp;melampirkan fotokopi hasil studi semester Kartu Hasi Studi (KHS) yang telah diperoleh;</p>\r\n\r\n<p>g.&nbsp;melampirkan sertifikat akreditasi program studi;</p>\r\n\r\n<p>h.&nbsp;melampirkan fotokopi SK Pengangkatan Dosen;</p>\r\n\r\n<p>i.&nbsp;melampirkan rencana penggunaan bantuan;&nbsp;</p>\r\n\r\n<p>j.&nbsp;surat pernyataan tidak sedang menerima bantuan beasiswa dari pihak lain yang diketahui oleh program studi/fakultas/perguruan tinggi;</p>\r\n\r\n<p>k.&nbsp;surat pernyataan bertanggung jawab dalam menggunakan dana bantuan beasiswa dan siap mengembalikan dana bantuan beasiswa apabila melanggar ketentuan yang telah ditetapkan; dan</p>\r\n\r\n<p>l.&nbsp;melampirkan rencana penelitian atau proposal penelitian berupa tugas akhir.</p>\r\n', '7,12,4,3,1,15,24,6,25,16,11,5', '2023-07-01', '2023-07-22', 10, NULL, 'A,B,C', '1,2,3,4,5,6', '3.50:3.50', 'Y', '7143b-e0f18-tanda_bukti_orange.docx');

--
-- Triggers `kategori`
--
DELIMITER $$
CREATE TRIGGER `kategori_before_insert` BEFORE INSERT ON `kategori` FOR EACH ROW BEGIN
	SET NEW.slug = slugify(NEW.nama);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `kategori_before_update` BEFORE UPDATE ON `kategori` FOR EACH ROW BEGIN
	SET NEW.slug = slugify(NEW.nama);
END
$$
DELIMITER ;
