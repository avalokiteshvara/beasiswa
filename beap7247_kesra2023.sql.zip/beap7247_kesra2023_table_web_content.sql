
-- --------------------------------------------------------

--
-- Table structure for table `web_content`
--

CREATE TABLE `web_content` (
  `id` int(11) NOT NULL,
  `judul` varchar(50) NOT NULL,
  `content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Truncate table before insert `web_content`
--

TRUNCATE TABLE `web_content`;
--
-- Dumping data for table `web_content`
--

INSERT INTO `web_content` (`id`, `judul`, `content`) VALUES
(1, 'juknis', ''),
(2, 'rundown', '<!DOCTYPE html>\r\n<html>\r\n<head>\r\n<style>\r\ntable {\r\n  font-family: arial, sans-serif;\r\n  border-collapse: collapse;\r\n  width: 100%;\r\n}\r\n\r\ntd, th {\r\n  border: 1px solid #dddddd;\r\n  text-align: left;\r\n  padding: 8px;\r\n}\r\n\r\ntr:nth-child(even) {\r\n  background-color: #dddddd;\r\n}\r\n</style>\r\n</head>\r\n<body>\r\n\r\n<table>\r\n  <tr>\r\n    <th>Tahapan Kegiatan</th>\r\n    <th>Waktu Pelaksanaan</th>\r\n    <th>Keterangan</th>\r\n  </tr>\r\n  <tr>\r\n    <td>Sosialisasi Program Beasiswa S-1,S-3</td>\r\n    <td>Juni 2023</td>\r\n    <td>Media Massa dan Perangkat Elektronik</td>\r\n  </tr>\r\n  <tr>\r\n    <td>Pendaftaran Beasiswa</td>\r\n    <td>1 - 22 Juli 2023</td>\r\n    <td>Online</td>\r\n  </tr>\r\n  <tr>\r\n    <td>Verifikasi Data Pendaftar</td>\r\n    <td>23 - 31 Juli 2023</td>\r\n    <td>Panitia</td>\r\n  </tr>\r\n  <tr>\r\n    <td>Pengumuman Calon Penerima Beasiswa Lolos Administrasi</td>\r\n    <td>1 Agustus 2023</td>\r\n    <td>Media Massa dan Perangkat Elektronik</td>\r\n  </tr>\r\n  <tr>\r\n    <td>Penyerahan Dokumen Autentik Bagi yang dinyatakan Lolos Administrasi Via POS</td>\r\n    <td>2 - 15 Agustus 2023</td>\r\n    <td>Tim Teknis</td>\r\n  </tr>\r\n  <tr>\r\n    <td>Seleksi Calon Penerima Bantuan oleh Tim Teknis</td>\r\n    <td>16 - 19 Agustus 2023</td>\r\n    <td>Tim Teknis</td>\r\n  </tr>\r\n\r\n   <tr>\r\n    <td>Seleksi dan Pengumuman Penerima Bantuan Beasiswa</td>\r\n    <td>20 Agustus - September 2023</td>\r\n    <td>Tim Seleksi</td>\r\n  </tr>\r\n   <tr>\r\n    <td>Penyiapan Dokumen Pencairan Beasiswa</td>\r\n    <td>September 2023</td>\r\n    <td>PPTK</td>\r\n  </tr>\r\n   <tr>\r\n    <td>Penyaluran Beasiswa</td>\r\n    <td>September - Oktober 2023</td>\r\n    <td>PPTK</td>\r\n  </tr>\r\n     <tr>\r\n    <td>Evaluasi</td>\r\n    <td>November - Desember 2023</td>\r\n    <td>Panitia</td>\r\n  </tr>\r\n</table>\r\n\r\n</body>\r\n</html>\r\n\r\n');
