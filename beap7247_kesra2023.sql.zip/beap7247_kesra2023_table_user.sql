
-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `level` enum('admin','verifikator','guest','questions') NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `hak_akses` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Truncate table before insert `user`
--

TRUNCATE TABLE `user`;
--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `level`, `username`, `password`, `hak_akses`) VALUES
(1, 'admin', 'admin', '80200b1dd62a4adfe4b83589a1dc33b7', '3,5,7,8'),
(30, 'questions', 'helpdesk', 'e10adc3949ba59abbe56e057f20f883e', '3,5,7,8'),
(31, 'guest', 'putri', 'e10adc3949ba59abbe56e057f20f883e', '3,5,7,8'),
(32, 'guest', 'yuli', 'e10adc3949ba59abbe56e057f20f883e', '3,5,7,8');
