
-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` int(11) NOT NULL,
  `pertanyaan` varchar(200) NOT NULL,
  `jawaban` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Truncate table before insert `faq`
--

TRUNCATE TABLE `faq`;
--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id`, `pertanyaan`, `jawaban`) VALUES
(1, 'Bagaimana cara melakukan pendaftaran online ?', '<p>Klik link pendaftaran pada halaman pendaftaran beasiswa, masukkan Nomor Induk Kependudukan (NIK) dan isi form yang telah disediakan dialamat website <a href=\"https://beasiswa.disdik.jambiprov.go.id\">http://beasiswa.jambiprov.go.id</a></p>\r\n\r\n<p>NIK harus kode wilayah Provinsi Jambi dan Pastikan alamat <strong>Email</strong> yang digunakan Valid dan masih digunakan dan<strong> No. Whatsapp</strong> yang masih aktif.</p>\r\n'),
(2, 'Kapan jadwal pendaftaran Beasiswa ?', '<p>Sesuai Petunjuk Teknis (<strong>JUKNIS</strong>) Pendaftaran Dibuka Pada Tanggal <strong>01 Juli 2023</strong> Sampai dengan <strong>22 Juli 2023</strong></p>\r\n'),
(3, 'Apakah yang dimaksud dengan NIK ?', '<p>NIK adalah Nomor Induk Kependudukan yang ada di Kartu Tanda Penduduk (KTP) yang berjumlah 16 (enam belas) digit angka.</p>\r\n'),
(4, 'Bisakah saya membuka website beasiswa menggunakan perangkat android/Smartphone ?', '<p>Untuk membaca informasi bisa, tetapi disarankan&nbsp;untuk login dan upload data diharuskan menggunakan Personal Computer (PC) atau Laptop.</p>\r\n'),
(5, 'Mengapa username dan password login saya belum diterima ?', '<p>Hal ini biasanya dikarenakan kesalahan dalam memasukkan alamat email dan no. Whatsapp. Alamat email&nbsp; dan no. Whatsapp harus benar dan masih aktif.</p>\r\n'),
(6, 'Siapa saja yang bisa ikut seleksi penerima beasiswa S1 dan S3?', '<p>Yang berhak ikut seleksi penerima beasiswa adalah Mahasiswa aktif dengan syarat : - Penduduk ber-KTP Provinsi Jambi - Mahasiswa aktif (bukan calon mahasiswa) duduk di minimal semester II - Meraih Indeks Prestasi Komulatif (IPK)&nbsp;paling rendah ; <strong>S1</strong> Index Prestasi Kumulatif (IPK) minimal 2,75 (dua koma tujuh lima) untuk mahasiswa eksakta dan minimal 3.00 (tiga koma nol nol) untuk mahasiswa sosial&nbsp;dan <strong>S3</strong> Indeks Prestasi Kumulatif (IPK) minimal 3,50 (tiga koma lima nol) - Akreditasi Program Studi minimal akreditasi B - Tidak sedang menerima bantuan pihak lain - <strong>Calon penerima diluar ketentuan diatas tidak bisa ikut seleksi penerima beasiswa</strong></p>\r\n'),
(7, 'Jika saya belum kuliah, bisakah saya ikut seleksi penerima beasiswa ?', '<p>Tidak bisa, beasiswa ini hanya untuk mahasiswa aktif.</p>\r\n'),
(8, 'Jika saya bukan penduduk Provinsi Jambi, bisakah saya ikut seleksi penerima beasiswa ?', '<p>Tidak bisa, hanya untuk penduduk ber-KTP Provinsi Jambi.</p>\r\n'),
(9, 'Apakah yang dimaksud dengan IPK dalam form pendaftaran ?', '<p>IPK adalah nilai Indeks Prestasi Komulatif, nilai yang diinput adalah nilai IPK di semester terakhir. Nilai IPK dibawah persyaratan tidak bisa ikut seleksi penerima beasiswa.</p>\r\n'),
(10, 'Apakah yang dimaksud dengan akreditasi program studi ?', '<p>Akreditasi Program Studi adalah nilai akreditasi yang diraih Program Studi tempat mahasiswa berkuliah minimal akreditasi B, akreditasi dibawah itu atau belum terakreditasi tidak bisa mengikuti seleksi penerima beasiswa.</p>\r\n'),
(11, 'Apakah yang dimaksud dengan sertifikat prestasi non akademik ?', '<p>Sertifikat non akademik adalah sertifikat atau piagam prestasi minimal di tingkat Provinsi di bidang Seni, Olah Raga, Sains Dll yang digunakan sebagai bahan pendukung penilaian seleksi beasiswa.</p>\r\n'),
(12, 'Apakah yang dimaksud dengan Fakta Integritas ?', '<p>Fakta Integritas adalah dokumen pernyataan kebenaran data dan dokumen peserta seleksi beasiswa yang wajib diunduh di halaman website beasiswa dan diisi serta ditandatangani diatas materai.</p>\r\n'),
(13, 'Wajibkah saya mengupload semua data ?', '<p>Semua data wajib diupload oleh peserta seleksi beasiswa, kecuali sertifikat/piagam prestasi hanya bagi yang memiliki prestasi non akademik.</p>\r\n'),
(15, 'Kapan peserta seleksi beasiswa Tahap I (Administrasi) diumumkan ?', '<p>Pada tanggal 1 Agustus 2023</p>\r\n'),
(16, 'Bagaimana cara verifikasi Tahap II (faktual)?', '<p>Calon penerima beasiswa mengirimkan berkas autentik via POS&nbsp;pada tanggal 2-15&nbsp;Agustus 2023. &nbsp;Jika terdapat data palsu/tidak benar, Calon penerima beasiswa didiskualifikasi</p>\r\n'),
(17, 'Informasi Tambahan ?', '<p>Tim Seleksi tidak bertanggung jawab apabila peserta seleksi salah memasukkan data diantaranya Nomor Handphone dan alamat email untuk keperluan komunikasi data/suara antara Tim Seleksi dan Peserta seleksi.</p>\r\n'),
(18, 'Saya sudah mendaftar akan tetapi NIK, IPK Semester, Akreditasi Program Studi yang saya inputkan salah, dan juga kesalahan upload dokumen apakah ada solusinya ?', '<p>Peserta dapat melakukan update data sendiri di sistem dengan cara login terlebih dahulu.</p>\r\n'),
(19, 'Saya salah memasukkan alamat E-mail apakah bisa login?', '<p>Ya, system bisa menerima akses melalui email (baik email yang valid ataupun tidak valid), dengan catatan, jika alamat email yang tidak valid dapat melapor pada support beasiswa di laman pertanyaan&nbsp;dan email : <strong>beasiswakesraprovjambi@gmail.com</strong></p>\r\n'),
(20, 'Saya mempunyai lebih dari satu sertifikat prestasi, bagaimana cara menguploadnya?', '<p>Silahkan data-data tersebut di .zip atau .rar dalam satu dokumen.</p>\r\n'),
(22, 'Saya sudah mendaftar akan tetapi belum mendapat email dan whatsapp untuk login, bagaimana solusinya?', '<p>Silahkan menghubungi Support di laman pertanyaan dan Email : <strong>beasiswakesraprovjambi@gmail.com</strong></p>\r\n'),
(23, 'Saya sudah upload dokumen, akan tetapi salah. adakah solusinya?', '<p>Silahkan upload kembali dokumen yang dimaksud, nantinya dokumen lama akan tergantikan dengan dokumen yang baru.</p>\r\n'),
(24, 'Jenis File apa saja dan ukuran file yang bisa diupload dalam sistem pendaftaran?', '<p>Inofrmasi yang wajib diketahui oleh pendaftar beasiswa :</p>\r\n\r\n<p>1. Ekstensi file unggah yang diijinkan : zip;rar;jpg;pdf;doc;docx;xls;xlsx<br />\r\n2. Besar file dokumen max 1 MBytes (1024 KB)</p>\r\n'),
(25, 'Akreditasi Program Studi itu di dapat dari mana?', '<p>Silahkan bertanya kepada pihak kampus baik itu ketua prodi atau ketua jurusan tempat saudara/i kuliah atau bisa juga mengecek secara online di laman website <a href=\"https://www.banpt.or.id/direktori/prodi/pencarian_prodi.php\">https://www.banpt.or.id/direktori/prodi/pencarian_prodi.php</a></p>\r\n'),
(28, 'NIK Daftar Kode Wilayah Provinsi Jambi', '<p>Daftar kode wilayah 11 kabupaten/kota di Provinsi Jambi yang terdiri dari 9 kabupaten dan 2 kota berdasarkan data yang dikeluarkan oleh Kementerian Dalam Negeri Republik Indonesia.</p>\r\n\r\n<table border=\"1\" cellpadding=\"5\" cellspacing=\"0\">\r\n	<thead>\r\n		<tr>\r\n			<th>\r\n			<p><strong>No</strong></p>\r\n			</th>\r\n			<th>\r\n			<p><strong>Kode Wilayah</strong></p>\r\n			</th>\r\n			<th>\r\n			<p><strong>Kabupaten/Kota</strong></p>\r\n			</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<p>1</p>\r\n			</td>\r\n			<td>\r\n			<p>15.01</p>\r\n			</td>\r\n			<td>\r\n			<p>Kabupaten Kerinci</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>2</p>\r\n			</td>\r\n			<td>\r\n			<p>15.02</p>\r\n			</td>\r\n			<td>\r\n			<p>Kabupaten Merangin</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>3</p>\r\n			</td>\r\n			<td>\r\n			<p>15.03</p>\r\n			</td>\r\n			<td>\r\n			<p>Kabupaten Sarolangun</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>4</p>\r\n			</td>\r\n			<td>\r\n			<p>15.04</p>\r\n			</td>\r\n			<td>\r\n			<p>Kabupaten Batanghari</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>5</p>\r\n			</td>\r\n			<td>\r\n			<p>15.05</p>\r\n			</td>\r\n			<td>\r\n			<p>Kabupaten Muaro Jambi</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>6</p>\r\n			</td>\r\n			<td>\r\n			<p>15.06</p>\r\n			</td>\r\n			<td>\r\n			<p>Kabupaten Tanjung Jabung Barat</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>7</p>\r\n			</td>\r\n			<td>\r\n			<p>15.07</p>\r\n			</td>\r\n			<td>\r\n			<p>Kabupaten Tanjung Jabung Timur</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>8</p>\r\n			</td>\r\n			<td>\r\n			<p>15.08</p>\r\n			</td>\r\n			<td>\r\n			<p>Kabupaten Bungo</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>9</p>\r\n			</td>\r\n			<td>\r\n			<p>15.09</p>\r\n			</td>\r\n			<td>\r\n			<p>Kabupaten Tebo</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>10</p>\r\n			</td>\r\n			<td>\r\n			<p>15.71</p>\r\n			</td>\r\n			<td>\r\n			<p>Kota Jambi</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>11</p>\r\n			</td>\r\n			<td>\r\n			<p>15.72</p>\r\n			</td>\r\n			<td>\r\n			<p>Kota Sungai Penuh</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p><a href=\"http://infopersada.com/jambi/pemerintahan-dan-wilayah/41-daftar-kode-wilayah-kabupaten-kota-di-jambi.html\">https://jdih.sulbarprov.go.id/peraturan/15.%20jambi.pdf</a></p>\r\n'),
(29, 'Apa yang dimaksud dengan NIDN', '<p><strong>Nomor Induk Dosen Nasional</strong>, yang selanjutnya disingkat dengan NIDN adalah nomor induk yang diterbitkan oleh Kementerian untuk dosen yang bekerja penuh waktu dan tidak sedang menjadi pegawai pada satuan adminstrasi pangkal/instansi yang lain.</p>\r\n'),
(30, 'Saya salah daftar pilihan beasiswa, apakah bisa melakukan perubahan?', '<p>Silahkan menghubungi Support Center Beasiswa di E-mail :&nbsp;<strong>beasiswakesraprovjambi@gmail.com</strong>&nbsp;dengan mencantumkan Identitas dan Subject yang jelas perihal kendala yang dimaksud.</p>\r\n'),
(31, 'Tahapan Pendaftaran Beasiswa Online', '<p><img alt=\"Alur-Pendaftaran-Beasiswa\" src=\"https://i.ibb.co/Lvkwgft/Alur-Pendaftaran-Beasiswa.png\" /></p>\r\n'),
(32, 'Cara Cek Penerima DTKS', '<p>Silahkan kunjungi laman :&nbsp;<a href=\"https://cekbansos.kemensos.go.id/\">https://cekbansos.kemensos.go.id/</a></p>\r\n');
