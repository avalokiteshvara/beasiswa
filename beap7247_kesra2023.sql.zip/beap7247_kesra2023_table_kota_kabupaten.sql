
-- --------------------------------------------------------

--
-- Table structure for table `kota_kabupaten`
--

CREATE TABLE `kota_kabupaten` (
  `id` varchar(36) NOT NULL,
  `prov_id` varchar(36) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Truncate table before insert `kota_kabupaten`
--

TRUNCATE TABLE `kota_kabupaten`;
--
-- Dumping data for table `kota_kabupaten`
--

INSERT INTO `kota_kabupaten` (`id`, `prov_id`, `kode`, `nama`) VALUES
('15.01', '15', '15.01', 'KAB. KERINCI'),
('15.02', '15', '15.02', 'KAB. MERANGIN'),
('15.03', '15', '15.03', 'KAB. SAROLANGUN'),
('15.04', '15', '15.04', 'KAB. BATANGHARI'),
('15.05', '15', '15.05', 'KAB. MUARO JAMBI'),
('15.06', '15', '15.06', 'KAB. TANJUNG JABUNG BARAT'),
('15.07', '15', '15.07', 'KAB. TANJUNG JABUNG TIMUR'),
('15.08', '15', '15.08', 'KAB. BUNGO'),
('15.09', '15', '15.09', 'KAB. TEBO'),
('15.71', '15', '15.71', 'KOTA JAMBI'),
('15.72', '15', '15.72', 'KOTA SUNGAI PENUH');
