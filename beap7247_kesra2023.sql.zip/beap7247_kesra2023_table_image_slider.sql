
-- --------------------------------------------------------

--
-- Table structure for table `image_slider`
--

CREATE TABLE `image_slider` (
  `id` int(11) NOT NULL,
  `url` varchar(250) DEFAULT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Truncate table before insert `image_slider`
--

TRUNCATE TABLE `image_slider`;
--
-- Dumping data for table `image_slider`
--

INSERT INTO `image_slider` (`id`, `url`, `category_id`) VALUES
(22, 'ee2f9-s1.png', 0),
(21, 'e9bc5-s3.png', 0),
(20, 'becfb-s2.png', 0),
(24, '25355-group-young-people-graduating_52683-40035-1.jpg', 0),
(25, '3313c-istockphoto-1062826694-612x612.jpg', 0);
