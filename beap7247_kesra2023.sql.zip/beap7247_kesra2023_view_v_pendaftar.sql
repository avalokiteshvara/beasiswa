
-- --------------------------------------------------------

--
-- Structure for view `v_pendaftar`
--
DROP TABLE IF EXISTS `v_pendaftar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`stsy7327`@`localhost` SQL SECURITY DEFINER VIEW `v_pendaftar`  AS SELECT `a`.`id` AS `id`, concat('tr_',`a`.`id`) AS `DT_RowId`, `a`.`nik` AS `nik`, `a`.`kategori_id` AS `kategori_id`, ucase(`a`.`nama_lengkap`) AS `nama_lengkap`, ucase(`a`.`kab_kota`) AS `kab_kota`, ucase(`a`.`jk`) AS `jk`, ucase(`a`.`nama_lembaga`) AS `nama_lembaga`, ucase(`a`.`program_studi`) AS `program_studi`, `a`.`akreditasi` AS `akreditasi`, `a`.`semester` AS `semester`, `a`.`ip_semester` AS `ip_semester`, concat(lpad(cast(count(distinct `b`.`id`) as unsigned),2,'0'),'-',lpad(cast(count(distinct `c`.`id`) as unsigned),2,'0'),'-',lpad(cast(count(distinct `d`.`id`) as unsigned),2,'0')) AS `dokumen`, `a`.`status` AS `status`, `a`.`status_akhir` AS `status_akhir`, `a`.`email` AS `email`, date_format(`a`.`created_at`,'%d-%m-%Y %H:%i:%s') AS `tgl_daftar` FROM (((`pendaftar` `a` left join `dokumen_pendaftar` `b` on(`a`.`id` = `b`.`pendaftar_id`)) left join `dokumen_pendaftar` `c` on(`a`.`id` = `c`.`pendaftar_id` and `c`.`verifikasi` = 'diterima')) left join `dokumen_pendaftar` `d` on(`a`.`id` = `d`.`pendaftar_id` and `d`.`verifikasi` = 'ditolak')) GROUP BY `a`.`id` ;
