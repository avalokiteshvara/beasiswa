
-- --------------------------------------------------------

--
-- Table structure for table `jenis_dokumen`
--

CREATE TABLE `jenis_dokumen` (
  `id` int(11) NOT NULL,
  `nama` varchar(200) DEFAULT NULL,
  `file_template` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Truncate table before insert `jenis_dokumen`
--

TRUNCATE TABLE `jenis_dokumen`;
--
-- Dumping data for table `jenis_dokumen`
--

INSERT INTO `jenis_dokumen` (`id`, `nama`, `file_template`) VALUES
(1, 'Kartu Tanda Penduduk (KTP)', NULL),
(2, 'Fakta Integritas', 'cde25-dd322-0426f-06334-fakta-integritas.doc'),
(3, 'Kartu Tanda Mahasiswa (KTM)', NULL),
(4, 'Kartu Keluarga (KK)', NULL),
(5, 'Transkrip Nilai / Kartu Hasil Studi (legalisir)', NULL),
(6, 'Surat Aktif Kuliah', NULL),
(7, 'Akreditasi Program Studi dari BAN-PT ', NULL),
(8, 'Sertifikat Prestasi Nasional dan Internasional (Jika memiliki, Jika tidak ada tidak perlu)', NULL),
(11, 'Surat Pernyataan Tidak Sedang Menerima Beasiswa dari Instansi/Lembaga Lain', '1c290-c0763-8ada5-740c9-surat-pernyataan-tidak-menerima-bantuan-beasiswa.docx'),
(12, 'Draft Proposal Disertasi', NULL),
(15, 'Rencana Penggunaan Dana Beasiswa', '05f91-85c72-5ba37-contoh-rencana-penggunaan-dana.xlsx'),
(16, 'Surat Pernyataan Bertanggung Jawab Mutlak', 'c6de4-surat-pertanggung-jawaban-mutlak.docx'),
(20, 'Kepgub Jambi tentang Penerima Beasiswa', '4efe7-kepgub-beasiswa-2018.pdf'),
(22, 'Surat Keterangan Bukti Terdaftar Program DTKS', NULL),
(24, 'SK Pengangkatan Dosen', NULL),
(25, 'Surat Permohonan', '2dac9-surat-permohonan-bantuan-beasiswa.docx'),
(26, 'Jenis Progaram Studi PTN Indonesia (Eksakta dan Non Eksakta)', '1cb06-jurusan_program_studi_ptn_di_indonesia_k.pdf'),
(27, 'Petunjuk Teknis Bantuan Beasiswa Tahun 2023', 'c111c-juknis-beasiswa-2023.pdf');
